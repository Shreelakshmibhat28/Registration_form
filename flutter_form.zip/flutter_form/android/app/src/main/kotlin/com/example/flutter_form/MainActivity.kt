package com.example.flutter_form

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
